import axios from 'axios';

const API_URL = 'https://6992b30a8a4d.ngrok.io/private/';

axios.defaults.headers.common = {
    Accept: "application/json, text/plain, */*"
};

export default class API {
    async send(url, method = 'GET', action, data = {}, params) {
        const response = await axios({
            method,
            url: `${url}${action}${window.location.search}${params ? params : ''}`,
            data
        }).catch(error => {
            console.error("Error API:", error);
        });
        return response ? response.data : [];
    }

    async Get(type,params) {
        const response = await this.send(API_URL, "GET", type, null, params);
        console.log("API: ", `Get ${type}`, response);

        return response;
    }

    async Post(data,params) {
        const response = await this.send(API_URL, "POST", `upload`, data, params);
        console.log("API: ", `Post`, response);

        return response;
    }
}