const cases_data = [
    {
        id: 1,
        name: "Летний кейс 1",
        img:"https://cdn.discordapp.com/attachments/738850161677172837/756902626293186570/unknown.png",
        price:"500",
        items: [
            {
                name: "Холодильник",
                img:"http://i2.rozetka.ua/goods/1698147/nord-403-010_images_1698147189.jpg",
                id: 1
            },
            {
                name: "Наушники",
                img:"https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fi.ytimg.com%2Fvi%2FX_ey8vnwfcE%2Fmaxresdefault.jpg&f=1&nofb=1",
                id: 2
            },
            {
                name: "Айфон 13",
                img:"https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fd3nevzfk7ii3be.cloudfront.net%2Figi%2FkBkXWHW5ImOiKqgM.large&f=1&nofb=1",
                id: 3
            },
            {
                name: "Подушка",
                img:"https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Fmyemoji.ru%2Fimage%2Fcache%2Fcatalog%2Fnovie_soznakom_obrezannie%2FPoop-700x700.jpg&f=1&nofb=1",
                id: 4
            },
            {
                name: "Ноутбук",
                img:"https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Fwww.ixbt.com%2Fportopc%2Facer%2Faspire-7535%2Fbig%2F45view-1620.jpg&f=1&nofb=1",
                id: 5
            },
        ]
    },
    {
        id: 2,
        name: "Летний кейс 2",
        img:"https://cdn.discordapp.com/attachments/738850161677172837/756902626293186570/unknown.png",
        price:"500",
        items: [
            {
                name: "Холодильник",
                img:"http://i2.rozetka.ua/goods/1698147/nord-403-010_images_1698147189.jpg",
                id: 1
            },
        ]
    },
    {
        id: 3,
        name: "Летний кейс 3",
        img:"https://cdn.discordapp.com/attachments/738850161677172837/756902626293186570/unknown.png",
        price:"500",
        items: [
            {
                name: "Холодильник",
                img:"http://i2.rozetka.ua/goods/1698147/nord-403-010_images_1698147189.jpg",
                id: 1
            },
        ]
    },
    {
        id: 4,
        name: "Летний кейс 3",
        img:"https://cdn.discordapp.com/attachments/738850161677172837/756902626293186570/unknown.png",
        price:"500",
        items: [
            {
                name: "Холодильник",
                img:"http://i2.rozetka.ua/goods/1698147/nord-403-010_images_1698147189.jpg",
                id: 1
            },
        ]
    },
    {
        id: 5,
        name: "Летний кейс 3",
        img:"https://cdn.discordapp.com/attachments/738850161677172837/756902626293186570/unknown.png",
        price:"500",
        items: [
            {
                name: "Холодильник",
                img:"http://i2.rozetka.ua/goods/1698147/nord-403-010_images_1698147189.jpg",
                id: 1
            },
        ]
    },
]

export default cases_data;