import React from 'react';
import PropTypes from 'prop-types';
import { platform, IOS, Button, Div, Group, Card, CardGrid } from '@vkontakte/vkui';
import Panel from '@vkontakte/vkui/dist/components/Panel/Panel';
import PanelHeader from '@vkontakte/vkui/dist/components/PanelHeader/PanelHeader';
import PanelHeaderButton from '@vkontakte/vkui/dist/components/PanelHeaderButton/PanelHeaderButton';
import Icon28ChevronBack from '@vkontakte/icons/dist/28/chevron_back';
import Icon24Back from '@vkontakte/icons/dist/24/back';

import Item from '../../content/main/item.main'

//import persik from '../../img/persik.png';
import '../../content/main/main.css';

const osName = platform();

const doubleArray = (arr) => {
    let newArr = []
    for (let i = 0; i < arr.length; i++) {
        if (arr[i+1]) {
            newArr.push([arr[i],arr[i+1]])
            i++
        }
        else newArr.push([arr[i]])
    }
    return newArr
}

const cases_data = [
    {
        name: "Холодильник",
        img:"http://i2.rozetka.ua/goods/1698147/nord-403-010_images_1698147189.jpg",
        id: 1
    },
    {
        name: "Наушники",
        img:"https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fi.ytimg.com%2Fvi%2FX_ey8vnwfcE%2Fmaxresdefault.jpg&f=1&nofb=1",
        id: 2
    },
    {
        name: "Айфон 13",
        img:"https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fd3nevzfk7ii3be.cloudfront.net%2Figi%2FkBkXWHW5ImOiKqgM.large&f=1&nofb=1",
        id: 3
    },
    {
        name: "Подушка",
        img:"https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Fmyemoji.ru%2Fimage%2Fcache%2Fcatalog%2Fnovie_soznakom_obrezannie%2FPoop-700x700.jpg&f=1&nofb=1",
        id: 4
    },
    {
        name: "Ноутбук",
        img:"https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Fwww.ixbt.com%2Fportopc%2Facer%2Faspire-7535%2Fbig%2F45view-1620.jpg&f=1&nofb=1",
        id: 5
    },
]

const Inventory = props => (
	<Panel id={props.id}>
		<PanelHeader
			left={<PanelHeaderButton onClick={props.go} data-to="home" data-type="panel">
				{osName === IOS ? <Icon28ChevronBack/> : <Icon24Back/>}
			</PanelHeaderButton>}
		>
			Инвентарь
		</PanelHeader>

        <Group style={{display:"block",margin:"0 auto",width:"100%"}} separator="hide">
        { doubleArray(cases_data).map(arr => (
            <CardGrid>
            { arr.map(data => (
                <Card size="m" mode="outline" className="card-item">
                    <div className="item-img" style={{background:`url(${data.img})`,backgroundSize:"cover",backgroundPosition:"center"}}>
                    </div>
                    <div className="card-box" style={{ minHeight:80, height:"inherit",width:"100%"}}>
                        <Item 
                        name={data.name}
                        price={data.price}
                        itid={data.id}
                        data-to="case"
                        data-type="panel"
                        onClick={props.go}
                        />
                    </div>
                </Card>
            )) }
            </CardGrid>
        )) }
        </Group>

	</Panel>
);

Inventory.propTypes = {
	id: PropTypes.string.isRequired,
	go: PropTypes.func.isRequired,
};

export default Inventory;
