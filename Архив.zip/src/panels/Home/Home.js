import React from 'react';
import PropTypes from 'prop-types';
import { Avatar, Div, PanelHeader, Panel, CardGrid, Card, Gradient, Group, Banner, Button } from '@vkontakte/vkui';
import Test from "../../module/test";
import "./Home.css";

import NavbarContent from "../../content/main/header.main"
import NavbarMenu from "../../content/main/menu.main"
import Cases from "../../content/main/content.main"

const Home = ({ id, go, fetchedUser }) => (
	<Panel id={id}>
		{fetchedUser &&
		<PanelHeader
		separator={false}
		left={
			<Div style={{display:"flex"}}>
				<Avatar style={{marginTop:"15px",border:"3px solid #fff"}} src={fetchedUser.photo_200} />
				<h1 className="name">SuperCase</h1>
			</Div>
		}>
		</PanelHeader>
		}

		<Div title="Navigation Example" separator={false}>
			<Gradient>
				<CardGrid>
					<Card size="l" mode="outline">
						<NavbarContent balance="200" count="1" />
					</Card>
				</CardGrid>
				<Group>
				<Banner
					mode="image"
					header="Бесплатный Кейс"
					subheader="Раз в 24 часа"
					background={
					<div
						style={{
						backgroundColor: '#65c063',
						backgroundImage: 'url(https://sun9-59.userapi.com/7J6qHkTa_P8VKRTO5gkh6MizcCEefz04Y0gDmA/y6dSjdtPU4U.jpg)',
						backgroundPosition: 'right bottom',
						backgroundSize: 320,
						backgroundRepeat: 'no-repeat',
						}}
					/>
					}
					actions={<Button mode="overlay_primary">Открыть</Button>}
				/>
				</Group>
				<NavbarMenu go={go} />
			</Gradient>
		</Div>
		<Div>
			<Cases go={go} />
		</Div>
	</Panel>
);

Home.propTypes = {
	id: PropTypes.string.isRequired,
	go: PropTypes.func.isRequired,
	fetchedUser: PropTypes.shape({
		photo_200: PropTypes.string,
		first_name: PropTypes.string,
		last_name: PropTypes.string,
		city: PropTypes.shape({
			title: PropTypes.string,
		}),
	}),
};

export default Home;
