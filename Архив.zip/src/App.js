import React, { useState, useEffect } from 'react';
import { ModalRoot, ModalCard, IOS, Button, Div, Alert  } from '@vkontakte/vkui';
import bridge from '@vkontakte/vk-bridge';
import View from '@vkontakte/vkui/dist/components/View/View';
import ScreenSpinner from '@vkontakte/vkui/dist/components/ScreenSpinner/ScreenSpinner';
import '@vkontakte/vkui/dist/vkui.css';

import Home from './panels/Home/Home';
import Persik from './panels/Persik/Persik';
import Inventory from './panels/Inventory/Inventory';
import Case from './panels/Case/Case';

import Payment from './modal/Payment.modal';
import Promo from './modal/Promo.modal';


const App = () => {
	const [activePanel, setActivePanel] = useState('home');
	const [fetchedUser, setUser] = useState(null);
	const [popout, setPopout] = useState(null);
	const [activeModal, setActiveModal] = useState(null);
	const [parse] = useState(window.location);
	const [cid, setCID] = useState(null)
	let [images, setImages] = useState(null)

	useEffect(() => {
		bridge.subscribe(({ detail: { type, data }}) => {
			if (type === 'VKWebAppUpdateConfig') {
				const schemeAttribute = document.createAttribute('scheme');
				schemeAttribute.value = data.scheme ? data.scheme : 'client_light';
				document.body.attributes.setNamedItem(schemeAttribute);
			}
		});
		async function fetchData() {
			const user = await bridge.send('VKWebAppGetUserInfo');
			setUser(user);
			setPopout(null);
		}
		fetchData();
	}, []);

	const go = e => {
		if (e.currentTarget.dataset.to === "case") setCID(e.currentTarget.dataset.cc)
		if (e.currentTarget.dataset.type === "modal") setActiveModal(e.currentTarget.dataset.to)
		if (e.currentTarget.dataset.type === "panel") setActivePanel(e.currentTarget.dataset.to)
	};

	const success = () => {
		setPopout(
			<Alert
			actionsLayout="vertical"
			actions={[{
			  title: 'Лишить права',
			  autoclose: true,
			  mode: 'destructive',
			  action: () => this.addActionLogItem('Пользователь больше не может модерировать контент.'),
			}, {
			  title: 'Отмена',
			  autoclose: true,
			  mode: 'cancel'
			}]}
			onClose={this.closePopout}
		  >
			<h2>Подтвердите действие</h2>
			<p>Вы уверены, что хотите лишить пользователя права на модерацию контента?</p>
		  </Alert>
		)
	}

	const modalWindow = (
		<ModalRoot activeModal={activeModal}>
			<ModalCard 
			id="payment"     
			header="Пополнить Баланс"
			onClose={() => {setActiveModal(null)}}
			>
				<Payment/>
			</ModalCard>
			<ModalCard 
			id="promo"
			header="Промокоды"
			success={success}
			onClose={() => {setActiveModal(null)}}
			>
				<Promo/>
			</ModalCard>
      </ModalRoot>
	);

	return (
		<View activePanel={activePanel} popout={popout} modal={modalWindow}>
			<Home id='home' fetchedUser={fetchedUser} go={go} parse={parse} />
			<Inventory id='inventory' fetchedUser={fetchedUser} go={go} parse={parse} />
			<Persik id='persik' go={go} />
			<Case id='case' go={go} cid={cid} images={images} setImages={setImages} />
		</View>
	);
}

export default App;

