import React from 'react';
import { Div, Button } from '@vkontakte/vkui';
import './case.css';
import cases_data from '../../api/db'

export default class Fortune extends React.Component {

    constructor(props)  {
        super(props)
        const appContext = React.createContext("App");
        console.log(props)
        this.cid = props.cid
        this.images = props.images
        this.setImages = props.setImages
        console.log(props.setImages)
        //this.renderImg(this.cid)
    }

    componentDidMount() {
        this.renderImg(this.cid)
    }

    getImage(case_id, img_id) {
        const case_data = cases_data.find(item => item.id === Number(case_id))
        const item_data = case_data.items.find(item => item.id === Number(img_id))
    
        return item_data.img 
    }

    setGrant(e) {
        const case_id = Number(e.target.dataset.id)
        this.randImages(case_id)
        console.log('generated')
    }

    getImages(id) {
        const acase = cases_data.find(item => item.id === Number(id));
    
        return acase.items.map(item => item.img)
    }

    renderImg(case_id, count = 5) {
        const images = this.getImages(case_id)
        const random = Math.random() * 100
        const result = []
    
        for (let i = 0; i <= count; i++) {
            let image = images[Math.floor(Math.random()*images.length)]
            //if (i == grant_num) image = "getImage(case_id, grant_id)"
            result.push(image)
        }
    
        this.setImages(result)
        console.log('result,this.images')
    }

    render() { 
        return (
            <div>
                <Div className="case-window">
                    { this.images.map(img => (
                    <div className="case-cover" style={{background:`url(${img})`,backgroundSize:"cover",backgroundPosition:"center"}}></div>
                    ))}
                </Div>
                <Button size="xl" mode="secondary" onClick={this.setGrant} stretched>Открыть</Button>
            </div>
        );
    }
}