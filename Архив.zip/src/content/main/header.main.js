import React from 'react'
import { Avatar, Div, Cell, Group, Button, PanelHeader, Header, Panel, CardGrid, Card, Gradient } from '@vkontakte/vkui';
import './main.css'

const NavbarMenu = ({balance, count}) => (
    <div style={{ height: 120, display:"flex", justifyContent:"space-between" }} >
        <Div>
        <span className="balance"><b>{balance}</b> Р</span>
        <span className="for-balance">Баланс:</span>
        </Div>
        <Div style={{textAlign:"right"}}>
        <span className="balance"><b>{count}</b></span>
        <span className="for-balance">Онлайн:</span>
        </Div>
    </div>
)

export default NavbarMenu;