import React from 'react'
import Icon28MoneyCircleOutline from '@vkontakte/icons/dist/28/money_circle_outline';
import Icon28CubeBoxOutline from '@vkontakte/icons/dist/28/cube_box_outline';
import Icon28KeyOutline from '@vkontakte/icons/dist/28/key_outline';
import { Div, Button } from '@vkontakte/vkui';

const Menu = [
    [   
        "Пополнить",
        "payment",
        "modal",
        <Icon28MoneyCircleOutline className="icon" width={60} height={60} />
    ],
    [   
        "Инвентарь",
        "inventory",
        "panel",
        <Icon28CubeBoxOutline className="icon" width={60} height={60} />
    ],
    [   
        "Промокоды",
        "promo",
        "modal",
        <Icon28KeyOutline className="icon" width={60} height={60} />
    ],
]

const NavbarContent = ({go}) => (
    <Div>
        <Div className="menu">
            { Menu.map(item => (
                <Button size="xl" stretched mode="secondary" data-to={item[1]} data-type={item[2]} onClick={go} style={{ marginRight:8,padding:5 }}>
                    {item[3]}
                </Button>
            ))}
        </Div>
        <Div className="sub-menu">
            { Menu.map(item => (
                <span style={{marginTop:5}} className="but-info">{item[0]}</span>
            ))}
        </Div>
    </Div>
)

export default NavbarContent;