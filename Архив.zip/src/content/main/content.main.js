import React from 'react'
import Icon28MoneyCircleOutline from '@vkontakte/icons/dist/28/money_circle_outline';
import { Avatar, Div, Cell, Group, Button, PanelHeader, Header, Panel, CardGrid, Card, Gradient } from '@vkontakte/vkui';
import './main.css'

import Case from './case.main'
import cases_data from '../../api/db'

const doubleArray = (arr) => {
    let newArr = []
    for (let i = 0; i < arr.length; i++) {
        if (arr[i+1]) {
            newArr.push([arr[i],arr[i+1]])
            i++
        }
        else newArr.push([arr[i]])
    }
    return newArr
}

const Cases = ({go}) => (
    <Group style={{display:"block",margin:"0 auto",width:"100%"}} separator="hide">
        { doubleArray(cases_data).map(arr => (
            <CardGrid>
            { arr.map(data => (
                <Card size="m" mode="outline" className="card-item">
                    <div className="item-img" style={{background:`url(${data.img})`,backgroundSize:"cover",backgroundPosition:"center"}}>
                    </div>
                    <div 
                    className="card-box" 
                    style={{ minHeight:80, height:"inherit",width:"100%"}}
                    data-to="case"
                    data-type="panel"
                    data-cc={data.id}
                    onClick={go}
                    >
                        <Case
                        name={data.name}
                        price={data.price}
                        img={data.img}
                        />
                    </div>
                </Card>
            )) }
            </CardGrid>
        )) }
    </Group>
)

export default Cases;