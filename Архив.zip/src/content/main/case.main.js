import React from 'react'
import Icon28MoneyCircleOutline from '@vkontakte/icons/dist/28/money_circle_outline';
import { Avatar, Div, Cell, Group, PanelHeader, Header, Panel, CardGrid, Card, Gradient, CellButton } from '@vkontakte/vkui';
import './main.css'

const Case = ({name, price, img}) => (
    <Div className="item-info">
        <div className="item-about">
            <span className="item-name">{name}</span>
        </div>
        <Div style={{display:'flex',flexWrap:'wrap',justifyContent:'center'}}>
            <span style={{marginLeft:5,marginTop:10}}>{price}Р</span>
        </Div>
        <CellButton size="l" style={{display:'flex',justifyContent:'center'}}>Открыть</CellButton>
    </Div>
)

export default Case;