self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d1be16492b5c71a9e7130558c2afd6e2",
    "url": "/index.html"
  },
  {
    "revision": "0c02fb1ba2ec544d67c9",
    "url": "/static/css/2.09e62520.chunk.css"
  },
  {
    "revision": "52da0da18d1144f6020b",
    "url": "/static/css/main.ae672e4c.chunk.css"
  },
  {
    "revision": "0c02fb1ba2ec544d67c9",
    "url": "/static/js/2.9698f4ce.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.9698f4ce.chunk.js.LICENSE.txt"
  },
  {
    "revision": "52da0da18d1144f6020b",
    "url": "/static/js/main.f45e23e5.chunk.js"
  },
  {
    "revision": "bde3be86d147a096631f",
    "url": "/static/js/runtime-main.944b771c.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);